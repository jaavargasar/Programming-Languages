#include<bits/stdc++.h>
#include <stdio.h>

using namespace std;

char chain1[1000];
char chain2[1000];
int main(){

    char c,d;
    int i=0;
    bool seen=false;
    FILE *fp, *fp1;
    fp = fopen("in.in","r");
    fp1= fopen("1.out","r");

    while(true){
        c = fgetc(fp);
        d = fgetc(fp1);
        //cout<<c<<" "<<d<<endl;
        if( feof(fp) && feof(fp1) ) break;
        if( c!=d){
            seen=true;
            //cout<<"here";
        }

    }
    if( seen) cout<<"wrong"<<endl;
    else cout<<"accept"<<endl;

    fclose(fp);
    fclose(fp1);

    return 0;
}
